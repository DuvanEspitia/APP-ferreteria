const mysql = require('mysql2');

// Configura los parámetros de conexión a tu base de datos MySQL local
const connection = mysql.createConnection({
  host: 'localhost:3306',     // Cambia esto a la dirección de tu servidor MySQL
  user: 'abccomer_root',          // Cambia esto al nombre de usuario de tu base de datos
  password: 'Abcuserbe-root',  // Cambia esto a la contraseña de tu base de datos
  database: 'myblog',    // Cambia esto al nombre de tu base de datos
});

// Conecta a la base de datos MySQL
connection.connect((err) => {
  if (err) {
    console.error('Error de conexión a la base de datos MySQL:', err);
  } else {
    console.log('Conectado a la base de datos MySQL');
  }
});

// Exporta la conexión para que puedas usarla en otros módulos
module.exports = connection;
