const express = require("express");
const app = express();
const cors = require("cors");
const rutainventario = require("./rutas/inventario");
const rutacategorias = require("./rutas/categorias");
const rutacaracteristicas = require("./rutas/caracteristicas");
const pagos = require("./rutas/pagos");
const bodyParser = require("body-parser");
const port = process.env.PORT || 3000;

// Example middleware to include CORS headers
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*'); 
  res.header('Access-Control-Allow-Methods', 'GET, POST, DELETE, PUT');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use("/api/pagos", pagos);
app.use("/api/inventario", rutainventario);
app.use("/api/categorias", rutacategorias);
app.use("/api/caracteristicas", rutacaracteristicas);

app.get("/", (req, res) => {
  res.send("Servidor Node.js en funcionamiento en el puerto " + port);
});

app.listen(port, () => {
  console.log(`El servidor está funcionando en el puerto ${port}`);
});
