const { Router } = require("express");
const mercadopago = require("mercadopago");
const dotenv = require("dotenv");
const nodemailer = require("nodemailer");
dotenv.config();

mercadopago.configure({
    access_token: process.env.ACCESS_TOKEN || "",
    client_id: process.env.MP_CLIENT_ID || "", 
    client_secret: process.env.MP_CLIENT_SECRET || "",
    
});

const Mercado_Pago = Router();
const EMAIL_USER = process.env.EMAIL_USER || "ventas@abccomercializadoraindustrial.com";
const EMAIL_PASSWORD = process.env.EMAIL_PASSWORD || "Ventasabc-2023";

const transporter = nodemailer.createTransport({
    host: 'mail.abccomercializadoraindustrial.com', // Use IPv4 address
    port: 465,
    secure: true,
    auth: {
        user: EMAIL_USER,
        pass: EMAIL_PASSWORD,
    },
});
Mercado_Pago.post("/", async (req, res) => {
    const { customerInfo, products } = req.body;

    try {
        const newArray = products.map((e) => {
            return {
                title: e.nombre,
                unit_price: e.precio,
                currency_id: "COP",
                quantity: e.cantidad,
            };
        });

        const preference = {
            items: newArray,
            payer:{
                email:customerInfo.email
            },
    
            back_urls: {
                success: `https://www.abccomercializadoraindustrial.com/PagoExitoso`,
                failure: "https://www.abccomercializadoraindustrial.com/Pagoerror",
            },
            notification_url: "https://app.abccomercializadoraindustrial.com/api/pagos/webhook",
            auto_return: "approved",
        };
       
        const respuesta = await mercadopago.preferences.create(preference);
        res.status(200).json(respuesta.response.init_point);
         const prePaymentMailOptions = {
            from: EMAIL_USER,
            to: EMAIL_USER,
            subject: 'Compra por confirmar',
            text: `Datos cliente \n
            cliente:
            nombre:${customerInfo.name}\n
            identificaci��n:${customerInfo.identificacion}\n
            Correo:${customerInfo.email}\n
            Direcci車n:${customerInfo.address}\n
            Numero:${customerInfo.phoneNumber}\n
            Departamento:${customerInfo.departamento}\n
            Ciudad:${customerInfo.ciudad}\n
            Factura Electronica:${customerInfo.facturaElectronica}\n
            ID compra:${respuesta.response.id}\n
            Detalles de la compra:\n${formatProductDetails(products)}`,
        };

        await transporter.sendMail(prePaymentMailOptions);
        
        console.log(respuesta);

    } catch (error) {
        res.status(500).json({error});
        return; // Exit the function to prevent further execution
    }
});
Mercado_Pago.post("/mercadopago-webhook", async (req, res) => {
    const payment = req.body;
    const idclient  = req.data.client_id
        res.status(200).send('ok');
   
});
Mercado_Pago.post('/webhook', async (req, res) => {
  const { type, data,date_created } = req.body;

 const partes = date_created.split('+');
 const fechaHora = partes[0].trim();
  try {
    handleNotification(type, data);

    const validationMailOptionsClient = {
      from: EMAIL_USER,
      to: EMAIL_USER,
      subject: 'Validación de Pago',
      text: `El pago fue aprobado:\n
       ID compra: ${data.id}\n
       Hora: ${fechaHora}
      
     
      
      `,
    
    };
    
       
            await transporter.sendMail(validationMailOptionsClient);
    
    
    res.status(200).send('OK');
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al procesar el pago' });
  }

  console.log(data);
});

const handleNotification =  (type, data) => {
  switch (type) {
    case 'payment':
      mercadopago.payment.findById(data.id, (err, payment) => {
        if (err) {
          console.error(err);
        } else {
          

          // Haz algo con el objeto payment
          console.log(payment);
        }
      });
      break;
    case 'plan':
      mercadopago.plan.findById(data.id, (err, plan) => {
        if (err) {
          console.error(err);
        } else {
          // Haz algo con el objeto plan
          console.log(plan);
        }
      });
      break;
    case 'subscription':
      mercadopago.subscription.findById(data.id, (err, subscription) => {
        if (err) {
          console.error(err);
        } else {
          // Haz algo con el objeto subscription
          console.log(subscription);
        }
      });
      break;
    case 'invoice':
      mercadopago.invoice.findById(data.id, (err, invoice) => {
        if (err) {
          console.error(err);
        } else {
          // Haz algo con el objeto invoice
          console.log(invoice);
        }
      });
      break;
    case 'point_integration_wh':
      // data contiene la información relacionada a la notificación
      break;
  }
};

function formatProductDetails(products) {
    return products.map(product => {
        return `Producto: ${product.name}\nPrecio: ${product.precio}\nCantidad: ${product.cantidad}\nREF:${product.referencia} \n--------\n`;
    }).join('');
} 
module.exports = Mercado_Pago;
