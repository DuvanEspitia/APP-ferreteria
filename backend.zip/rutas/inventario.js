const express = require("express");
const router = express.Router();
const multer = require("multer");
const upload = multer(); // Configures multer for in-memory file uploads
const { Sequelize, DataTypes } = require("sequelize");

// Initialize Sequelize and connect to your SQL database
const sequelize = new Sequelize("abccomer_myblog", "abccomer_web", "gkSfHKtNo)fT", {
  host: "localhost",
  dialect: "mysql", // You may need to change this to match your SQL database type
});

// Define the model for your SQL database
const Inventario = sequelize.define("inventarios", {
  idinventarios: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  Nom_prodct: DataTypes.STRING,
  Cant_prodct: DataTypes.INTEGER,
  Marca_prodct: DataTypes.STRING,
  Dimensiones_prodct: DataTypes.STRING,
  image: DataTypes.BLOB('long'), // Ajusta el tipo de datos según tu base de datos SQL
  idcategoria: DataTypes.INTEGER,
}, {
  timestamps: false, // Agrega esta línea para excluir marcas de tiempo
});


// Create the table if it doesn't exist
sequelize.sync();

// Route to add a product to the inventory
router.post('/agregarInventario', upload.single('image'), async (req, res) => {
  try {
    const imageBuffer = req.file ? req.file.buffer : null;

    const nuevoinventario = await Inventario.create({
      Nom_prodct: req.body.Nom_prodct,
      Cant_prodct: req.body.Cant_prodct,
      Marca_prodct: req.body.Marca_prodct,
      Dimensiones_prodct: req.body.Dimensiones_prodct,
      image: imageBuffer,
      idcategoria: req.body.idcategoria,
    });

    res.status(200).send(nuevoinventario);
  } catch (err) {
    res.send(err);
  }
});
// consulta producto
router.post('/obtenerdataproducto', async (req, res) => {
  try {
    const producto = await Inventario.findOne({
      where: { idinventarios: req.body.idinventarios }
    });

    if (producto) {
      // Convierte la imagen a base64 si existe
      let base64Image = null;
      if (producto.image) {
        base64Image = Buffer.from(producto.image).toString('base64');
      }

      // Devuelve el producto con la imagen en formato base64
      res.json({
        idinventarios: producto.idinventarios,
        Nom_prodct: producto.Nom_prodct,
        Cant_prodct: producto.Cant_prodct,
        Marca_prodct: producto.Marca_prodct,
        Dimensiones_prodct: producto.Dimensiones_prodct,
        image: base64Image,
        idcategoria: producto.idcategoria,
      });
    } else {
      res.status(404).json({ message: 'Producto no encontrado' });
    }
  } catch (err) {
    console.error(err);
    res.status(500).send('Error en la consulta' + err);
  }
});
// Route to retrieve all products in the inventory
router.get('/consultarinventario', async (req, res) => {
  try {
    const inventario = await Inventario.findAll();
    const inventarioWithBase64Image = inventario.map(inventario => {
      let base64Image = null;
      if (inventario.image) {
        base64Image = Buffer.from(inventario.image).toString('base64');
      }
      return {
        id: inventario.idinventarios,
        Nom_prodct: inventario.Nom_prodct,
        Cant_prodct: inventario.Cant_prodct,
        Marca_prodct: inventario.Marca_prodct,
        Dimensiones_prodct: inventario.Dimensiones_prodct,
        image: base64Image,
        idcategoria: inventario.idcategoria,
      };
    });

    res.json(inventarioWithBase64Image);
  } catch (err) {
    console.error(err);
    res.status(500).send('Error en la consulta' + err);
  }
});
///Actualizar el producto
router.post('/actualizarproducto', upload.single('image'), async (req, res) => {
  const imageBuffer = req.file ? req.file.buffer : null;

  try {
    const producto = await Inventario.findOne({
      where: { idinventarios: req.body.idinventarios }
    });
        
    if (producto) {
      // Actualiza los atributos del producto
      producto.Nom_prodct = req.body.Nom_prodct;
      producto.Cant_prodct = req.body.Cant_prodct;
      producto.Marca_prodct = req.body.Marca_prodct;
      producto.Dimensiones_prodct = req.body.Dimensiones_prodct;
      producto.idcategoria = req.body.idcategoria;

      // Actualiza la imagen solo si se cargó una nueva
      if (imageBuffer) {
        producto.image = imageBuffer;
      }

      // Guarda los cambios en la base de datos
      await producto.save();

      res.status(200).json(producto);
    } else {
      res.status(404).json({ message: 'Producto no encontrado' });
    }
  } catch (err) {
    console.error(err);
    res.status(500).send('Error en la consulta');
  }
});

// Add other routes for updating, deleting, and retrieving product data as needed
// En tus rutas

// Ruta para eliminar un producto por ID
router.delete('/eliminarproducto/:id', async (req, res) => {
  try {
    const productId = req.params.id; // Obtiene el ID del producto de los parámetros de la URL

    // Busca el producto por ID
    const producto = await Inventario.findOne({
      where: { idinventarios: productId }
    });

    if (producto) {
      // Si se encontró el producto, procede a eliminarlo
      await producto.destroy();

      res.status(200).json({ message: 'Producto eliminado con éxito' });
    } else {
      // Si el producto no se encontró, devuelve un mensaje de error
      res.status(404).json({ message: 'Producto no encontrado' });
    }
  } catch (err) {
    console.error(err);
    res.status(500).send('Error en la consulta' +err);
  }
});


module.exports = router;
