const express = require("express");
const router = express.Router();
const { Sequelize, DataTypes } = require("sequelize");

// Initialize Sequelize and connect to your SQL database
const sequelize = new Sequelize("abccomer_myblog", "abccomer_web", "gkSfHKtNo)fT", {
  host: "localhost",
  dialect: "mysql", // You may need to change this to match your SQL database type
});

  
// Define the model for your SQL database with timestamps disabled
const Categoria = sequelize.define("categoria", {
    idcategoria: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    nombre: DataTypes.STRING,
    caracteristica: DataTypes.STRING,
}, {
    timestamps: false, // Disable timestamps
});

// Route to add a category
router.post('/agregarcategoria', async (req, res) => {
    try {
        const nuevaCategoria = await Categoria.create({
            nombre: req.body.nombre,
            caracteristica: req.body.caracteristica,
        });

        res.status(200).send("Categoría agregada correctamente");
    } catch (err) {
        res.send(err);
    }
});

// Route to retrieve all categories
router.get('/consultarcategoria', async (req, res) => {
    try {
        const categorias = await Categoria.findAll();

        // Check if any categories were found
        if (categorias.length === 0) {
            return res.status(404).json({ message: 'No se encontraron categorías' });
        }

        // Build an array of response objects for all categories
        const respuesta = categorias.map(categoria => ({
            idcategoria: categoria.idcategoria,
            nombre: categoria.nombre,
            caracteristica: categoria.caracteristica,
        }));

        return res.json(respuesta);
    } catch (err) {
        console.error(err);
        res.status(500).send('Error en la consulta'+err);
    }
});

// Add a route to retrieve a specific category by ID (similar to the original code)

// Define additional routes for updating, deleting, and retrieving category data as needed

module.exports = router;
