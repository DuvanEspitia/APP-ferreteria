const express = require("express");
const router = express.Router();
const { Sequelize, DataTypes } = require("sequelize");

// Initialize Sequelize and connect to your SQL database
const sequelize = new Sequelize("abccomer_myblog", "abccomer_web", "gkSfHKtNo)fT", {
    host: "localhost",
    dialect: "mysql", // You may need to change this to match your SQL database type
  });
  
// Define the model for your SQL database with timestamps disabled
const Caracteristicas = sequelize.define("caracteristicas", {
    idcaracteristicas: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    nombre: DataTypes.STRING,
    precio: DataTypes.INTEGER,
    codigo: DataTypes.STRING,
    cantidad: DataTypes.INTEGER,
    idinventarios: DataTypes.INTEGER
}, {
    timestamps: false, 
});

router.post('/agregarcaracteristicas', async (req, res) => {
    try {
        const nuevaCategoria = await Caracteristicas.create({
            nombre: req.body.nombre,
            precio: req.body.precio,
            codigo: req.body.codigo,
            cantidad: req.body.cantidad,
            idinventarios:  req.body.idinventarios
        });

        res.status(200).send("Caracteristicas agregada correctamente"+ nuevaCategoria);
         res.status(204).send("Caracteristicas agregada correctamente"+ nuevaCategoria);
    } catch (err) {
        res.send(err);
    }
});

router.get('/consultarcaracteristicas', async (req, res) => {
    try {
        const caracteristicas = await Caracteristicas.findAll();
        if (caracteristicas.length === 0) {
            return res.status(404).json({ message: 'No se encontraron Caracteristicas' });
        }
        const respuesta = caracteristicas.map(caracteristicas => ({
            idcaracteristicas: caracteristicas.idcaracteristicas,
            nombre: caracteristicas.nombre,
            precio: caracteristicas.precio,
            codigo: caracteristicas.codigo,
            cantidad: caracteristicas.cantidad,
            idinventarios: caracteristicas.idinventarios,
        }));
        return res.json(respuesta);
    } catch (err) {
        console.error(err);
        res.status(500).send('Error en la consulta'+ err);
    }
});
router.get('/consultarcaracteristicas/:idinventarios', async (req, res) => {
    const idinventarios = req.params.idinventarios;

    try {
        // Consulta las características que coinciden con el idinventarios proporcionado
        const caracteristicas = await Caracteristicas.findAll({
            where: { idinventarios: idinventarios }
        });

        if (caracteristicas.length === 0) {
            return res.status(404).json({ message: 'No se encontraron Caracteristicas para el idinventarios proporcionado' });
        }

        const respuesta = caracteristicas.map(caracteristica => ({
            idcaracteristicas: caracteristica.idcaracteristicas,
            nombre: caracteristica.nombre,
            precio: caracteristica.precio,
            codigo: caracteristica.codigo,
            cantidad: caracteristica.cantidad,
            idinventarios: caracteristica.idinventarios
        }));

        return res.json(respuesta);
    } catch (err) {
        console.error(err);
        res.status(500).send('Error en la consulta' + err);
    }
});
// Ruta para eliminar una caracteristica por ID
router.delete('/eliminarcarac/:id', async (req, res) => {
  try {
    const productId = req.params.id; // Obtiene el ID del producto de los parámetros de la URL

    // Busca todas las características con el mismo idinventarios
    const caracteristicas = await Caracteristicas.findAll({
      where: { idinventarios: productId }
    });

    if (caracteristicas.length > 0) {
      // Si se encontraron características, procede a eliminarlas
      await Caracteristicas.destroy({ where: { idinventarios: productId } });

      res.status(200).json({ message: 'Características eliminadas con éxito' });
    } else {
      // Si no se encontraron características, devuelve un mensaje de error
      res.status(404).json({ message: 'Características no encontradas' });
    }
  } catch (err) {
    console.error(err);
    res.status(500).send('Error en la consulta');
  }
});


router.delete('/eliminarunacarac/:id', async (req, res) => {
  try {
    const productId = req.params.id; // Obtiene el ID del producto de los parámetros de la URL

    // Busca el producto por ID
    const producto = await Caracteristicas.findOne({
      where: { idcaracteristicas: productId }
    });

    if (producto) {
      // Si se encontró el producto, procede a eliminarlo
      await producto.destroy();

      res.status(200).json({ message: 'caracteristica eliminado con éxito' });
    } else {
      // Si el producto no se encontró, devuelve un mensaje de error
      res.status(404).json({ message: 'caracteristica no encontrado' });
    }
  } catch (err) {
    console.error(err);
    res.status(500).send('Error en la consulta');
  }
});
module.exports = router;
